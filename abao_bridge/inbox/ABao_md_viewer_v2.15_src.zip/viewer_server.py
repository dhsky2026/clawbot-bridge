#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MD Viewer Pro — 本地服务端（打包友好版 v2）

相对 v1 的三项「打包友好」改造（应 AGui 02131 要求）：
  1. 资源路径打包感知：sys._MEIPASS 优先，回退 __file__ 目录
  2. 文件根可配置 + 自动探测：--root > exe 同级 root.txt > 向上探测含 stock/规则中心 的目录 > cwd
  3. 输出流安全：--noconsole 下 sys.stdout 可能为 None 或 GBK 管道，
     无条件把 stdout/stderr 重定向到 UTF-8 日志文件，杜绝 UnicodeEncodeError 崩溃

无窗版必备（已预留）：
  - GET /shutdown   网页「⏻ 关闭服务」调用，优雅退出
  - 失败弹窗         Windows 下 ctypes.windll.user32.MessageBoxW，非 Windows 降级为日志

零第三方依赖（仅标准库），PyInstaller onedir + noconsole 可直接打包。
"""
import argparse
import io
import json
import os
import sys
import threading
import time
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from socket import socket, AF_INET, SOCK_STREAM
from urllib.parse import urlparse, parse_qs, unquote

MD_EXT = ('.md', '.markdown', '.mdown', '.mkd')
SKIP_DIRS = {'.git', 'node_modules', '__pycache__', '.venv', 'venv',
             '.idea', '.vscode', 'dist', 'build', '.DS_Store'}
PROBE_MARKERS = [os.path.join('stock', '规则中心'), os.path.join('stock', '端口'),
                 '规则中心', 'stock']

# ---- 修复（02158 真因①）：Windows 保留设备名 ----
# 项目里若存在名为 nul / con / aux / prn / com1..9 / lpt1..9 的条目（含扩展名变体），
# os.path.join 后 os.path.relpath 会抛 ValueError: path is on mount 设备路径。
RESERVED_NAMES = {
    'con', 'prn', 'aux', 'nul',
    'com1', 'com2', 'com3', 'com4', 'com5', 'com6', 'com7', 'com8', 'com9',
    'lpt1', 'lpt2', 'lpt3', 'lpt4', 'lpt5', 'lpt6', 'lpt7', 'lpt8', 'lpt9',
    'conin$', 'conout$',
}


def entry_ok(name):
    """条目名是否安全可遍历：过滤 Windows 保留设备名（含 'nul.txt' 这类带扩展名变体）。"""
    if not name or name in ('.', '..'):
        return False
    stem = os.path.splitext(name)[0].lower()
    return stem not in RESERVED_NAMES

# ============================================================
# 改造③：输出流安全 —— 必须在任何 print 之前执行
# ============================================================
def _safe_stdio():
    """把 stdout/stderr 无条件重定向到 UTF-8 日志文件。
    --noconsole 模式下 sys.stdout 可能是 None；控制台模式下可能是 GBK 管道，
    两者都会让含中文/emoji 的 print 抛 UnicodeEncodeError 并直接崩溃。
    """
    try:
        logdir = os.path.join(os.path.expanduser('~'), '.mdviewer')
        os.makedirs(logdir, exist_ok=True)
        logpath = os.path.join(logdir, 'mdviewer.log')
    except Exception:
        logpath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mdviewer.log')
    try:
        # 修复（02158/02161/02162 真因②）：open(..., encoding=) 返回的已是文本流，
        # 再包一层 io.TextIOWrapper 会抛 TypeError（"连弹好几个窗"的元凶）。
        # 直接赋值为 open() 的返回值即可，不二次包装。
        # buffering=1 → 行缓冲（文本模式），保证日志即时落盘；
        # 若用默认块缓冲，程序被强杀时日志会整段丢失。
        f = open(logpath, 'a', encoding='utf-8', errors='replace', buffering=1)
        sys.stdout = f
        sys.stderr = f
    except Exception:
        # 兜底：至少保证不是 None，避免 print 直接炸
        if sys.stdout is None:
            sys.stdout = io.StringIO()
        if sys.stderr is None:
            sys.stderr = sys.stdout
    return logpath


LOGPATH = _safe_stdio()


def log(msg):
    try:
        print('[%s] %s' % (time.strftime('%H:%M:%S'), msg))
    except Exception:
        pass


# ============================================================
# 失败弹窗（无窗版静默失败时给明确提示）
# ============================================================
def alert(title, msg):
    log('ALERT %s: %s' % (title, msg))
    try:
        if sys.platform == 'win32':
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, str(msg), str(title), 0x10)  # 0x10=错误图标
            return
    except Exception as e:
        log('弹窗失败: %s' % e)
    # 非 Windows 或弹窗失败：仅写日志


# ============================================================
# 改造①：资源路径打包感知
# ============================================================
def resource_base():
    """exe 运行时资源被解压到临时目录 _MEIPASS；源码运行时用 __file__ 目录。"""
    base = getattr(sys, '_MEIPASS', None)
    if base:
        return base
    return os.path.dirname(os.path.abspath(__file__))


RES_BASE = resource_base()


def find_page():
    for name in ('md-viewer-pro.html', 'index.html'):
        p = os.path.join(RES_BASE, name)
        if os.path.isfile(p):
            return p
    # 再找一次 cwd（开发态容错）
    for name in ('md-viewer-pro.html', 'index.html'):
        p = os.path.join(os.getcwd(), name)
        if os.path.isfile(p):
            return p
    return None


# ============================================================
# 改造②：文件根可配置 + 自动探测
# ============================================================
def resolve_root(cli_root=None):
    """优先级：--root > exe 同级 root.txt > 向上探测标记目录 > cwd"""
    # 1) 命令行
    if cli_root:
        p = os.path.abspath(cli_root)
        if os.path.isdir(p):
            log('根目录来源: --root = %s' % p)
            return p
        alert('MD Viewer 启动失败',
              '指定的 --root 不是有效目录，请检查 --root 路径：\n%s\n\n'
              '排查建议：\n'
              '1) 确认路径存在且为目录\n'
              '2) 路径含空格请用英文双引号包裹\n'
              '3) 也可在程序目录放 root.txt（首行写路径）\n'
              '4) 不传 --root 则自动探测，兜底用程序所在目录' % cli_root)
        log('--root 无效: %s' % cli_root)

    # 2) exe / 脚本同级 root.txt
    for base_dir in (RES_BASE, os.path.dirname(os.path.abspath(__file__)), os.getcwd()):
        try:
            txt = os.path.join(base_dir, 'root.txt')
            if os.path.isfile(txt):
                with open(txt, 'r', encoding='utf-8', errors='replace') as f:
                    line = f.readline().strip().strip('"').strip("'")
                if line and os.path.isdir(line):
                    log('根目录来源: root.txt = %s' % line)
                    return os.path.abspath(line)
        except Exception as e:
            log('读取 root.txt 失败: %s' % e)

    # 3) 向上探测（找含 stock/规则中心 的祖先目录）
    # 🔴 02214 真因修复：原实现是「先按层、再按 marker」的立即返回 ——
    #   PROBE_MARKERS 里既有组合 marker（stock/规则中心）又有单项 marker（规则中心 / stock），
    #   于是扫到 D:\...\ClawBot\stock 这一层时，单项 '规则中心' 先命中就直接返回了 stock，
    #   比真正的项目根 D:\...\ClawBot **深了一层**。
    #   后果：文档相对路径凭空多一层前缀，<img src="../../../x.ico"> 上溯就越出 root，
    #         服务端 _safe 判越界 → 404（主公反馈「测试 md 第一张图看不到」的真因）。
    #   修法：扫全部祖先，收集命中，按「组合 marker 优先 → 路径最靠根」取最优。
    cur = os.path.abspath(os.getcwd())
    ancestors = []
    for _ in range(8):
        ancestors.append(cur)
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent

    combo = [m for m in PROBE_MARKERS if os.sep in m]
    single = [m for m in PROBE_MARKERS if os.sep not in m]
    best = None
    for depth, base in enumerate(ancestors):
        if any(os.path.isdir(os.path.join(base, m)) for m in combo):
            pri = 0
        elif any(os.path.isdir(os.path.join(base, m)) for m in single):
            pri = 1
        else:
            continue
        cand = (pri, -depth)          # 组合优先；同档取更靠根（depth 更大）
        if best is None or cand < best[0:2]:
            best = (pri, -depth, base)
    if best:
        log('根目录来源: 自动探测命中 -> %s（优先级 %d · 祖先深度足以定位项目根）'
            % (best[2], best[0]))
        return best[2]

    # 4) 兜底 cwd
    log('根目录来源: 兜底 cwd = %s' % os.getcwd())
    return os.path.abspath(os.getcwd())


# ============================================================
# HTTP 服务
# ============================================================
def _mtime(p):
    try:
        return int(os.path.getmtime(p))
    except Exception:
        return 0


def count_md(nodes):
    """递归统计子树内 md 文件数量（用于「N md」徽标）"""
    n = 0
    for x in nodes or []:
        if x.get('type') == 'md':
            n += 1
        elif x.get('type') == 'dir':
            n += x.get('n_md') or count_md(x.get('children'))
    return n


def has_md_dir(d):
    """目录（含子孙）是否含 md —— 用于前端决定加粗/淡化"""
    try:
        for dp, dns, fns in os.walk(d):
            dns[:] = [x for x in dns
                      if x not in SKIP_DIRS and entry_ok(x)
                      and not os.path.islink(os.path.join(dp, x))]
            for fn in fns:
                if entry_ok(fn) and fn.lower().endswith(MD_EXT):
                    return True
    except Exception:
        pass
    return False


def port_in_use(port, host='127.0.0.1', timeout=0.35):
    """连接探测端口是否已有实例在监听（不 bind，避免与 allow_reuse_address 语义纠缠）。"""
    s = socket(AF_INET, SOCK_STREAM)
    s.settimeout(timeout)
    try:
        return s.connect_ex((host, port)) == 0
    except Exception:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


class ViewerServer(ThreadingHTTPServer):
    """修复（02165 真因）：
    HTTPServer.allow_reuse_address = 1，Windows 下会让新实例在已占用端口上"再次绑定成功"，
    导致端口顺延永远不触发、每次双击都留下一个隐藏进程（表现为打开 8795 却是空白页）。
    这里显式关掉 reuse，并改用多线程，避免并发请求串行排队。
    """
    allow_reuse_address = False
    daemon_threads = True


class ViewerHandler(SimpleHTTPRequestHandler):
    root = os.getcwd()
    server_holder = None   # 供 /shutdown 调用

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def _text(self, s, code=200, ctype='text/plain; charset=utf-8'):
        body = s.encode('utf-8') if isinstance(s, str) else s
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def _safe(self, rel):
        base = os.path.realpath(self.root)
        target = os.path.realpath(os.path.join(base, rel or '.'))
        if target == base or target.startswith(base + os.sep):
            return target
        return None

    def do_POST(self):
        """009（主公）：接收前端保存的收藏/历史（跨端口持久化）。"""
        q = urlparse(self.path)   # 009：本文件是 from urllib.parse import urlparse
        if q.path == "/api/prefs":
            return self._api_prefs()
        self._json({"error": "not found"}, 404)

    def do_GET(self):
        u = urlparse(self.path)
        path, qs = u.path, parse_qs(u.query)

        if path in ('/', '/index.html', '/md-viewer-pro.html'):
            return self._serve_page()
        if path == '/api/tree':
            return self._api_tree(qs.get('path', [''])[0])
        if path == '/api/file':
            return self._api_file(qs.get('path', [''])[0])
        if path == '/api/search':
            return self._api_search(qs.get('q', [''])[0], qs.get('mode', ['full'])[0])
        if path == '/api/prefs':
            return self._api_prefs()
        if path == '/api/ping':
            return self._json({'ok': True, 'root': self.root,
                               'shutdown': '/shutdown'})
        if path == '/api/open':
            return self._api_open(qs.get('path', [''])[0])
        if path.startswith('/files/'):
            return self._serve_raw(unquote(path[len('/files/'):]))
        # ---- 修复（02165③）：前端依赖本地化，/static/ 提供 assets/ 下的静态资源 ----
        if path.startswith('/static/'):
            return self._serve_static(unquote(path[len('/static/'):]))
        # ---- 无窗版必备：关闭服务 ----
        if path == '/shutdown':
            return self._shutdown()
        return self._json({'error': 'not found', 'path': path}, 404)

    def _serve_page(self):
        p = find_page()
        if not p:
            alert('MD Viewer 启动失败', '找不到前端页面 md-viewer-pro.html')
            return self._text('<h1>md-viewer-pro.html 缺失</h1>', 404,
                              'text/html; charset=utf-8')
        with open(p, 'rb') as f:
            return self._text(f.read(), ctype='text/html; charset=utf-8')

    def _shutdown(self):
        self._json({'ok': True, 'msg': '服务即将关闭'})
        log('收到 /shutdown，准备退出')

        def _kill():
            time.sleep(0.4)
            try:
                self.server_holder.shutdown()
            except Exception:
                pass
            os._exit(0)
        threading.Thread(target=_kill, daemon=True).start()

    # 009（主公）：收藏/历史跨端口持久化 —— 端口动态分配，localStorage 按 origin
    #   隔离 ⇒ 换端口即丢。改存用户目录，跨端口/跨会话保命。
    def _api_prefs(self):
        d = os.path.join(os.path.expanduser('~'), '.dh_mdviewer')
        f = os.path.join(d, 'prefs.json')
        if self.command == 'POST':
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                raw = self.rfile.read(ln).decode('utf-8', 'replace') if ln else '{}'
                obj = json.loads(raw)
                if not isinstance(obj, dict):
                    raise ValueError('bad payload')
                os.makedirs(d, exist_ok=True)
                # 009：合并写入（两版共用同一 prefs 文件，键名不同，不能整体覆盖）
                cur = {}
                try:
                    if os.path.isfile(f):
                        with open(f, 'r', encoding='utf-8') as fp:
                            cur = json.load(fp) or {}
                except Exception:
                    cur = {}
                if not isinstance(cur, dict):
                    cur = {}
                cur.update(obj)
                tmp = f + '.tmp'
                with open(tmp, 'w', encoding='utf-8') as fp:
                    json.dump(cur, fp, ensure_ascii=False, indent=1)
                os.replace(tmp, f)
                return self._json({'ok': True, 'keys': len(obj), 'total': len(cur)})
            except Exception as e:
                return self._json({'error': str(e)}, 400)
        try:
            if os.path.isfile(f):
                with open(f, 'r', encoding='utf-8') as fp:
                    return self._json(json.load(fp))
        except Exception:
            pass
        return self._json({})

    # 009（主公）：全文搜索 —— 文件名命中 + 内容命中（内容限 8MB/文件、最多 60 条）
    def _api_search(self, q, mode='full'):
        # 02204（主公）：mode=name 只搜文件名；mode=full 文件名 + 正文内容（两者分开）
        only_name = (str(mode).lower() == 'name')
        q = (q or '').strip()
        if not q:
            return self._json({'results': [], 'mode': 'fulltext'})
        base = os.path.realpath(self.root)
        ql = q.lower()
        hits = []
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [d for d in dirnames
                           if d not in SKIP_DIRS and entry_ok(d)
                           and not os.path.islink(os.path.join(dirpath, d))]
            for fn in filenames:
                if not entry_ok(fn) or not fn.lower().endswith(MD_EXT):
                    continue
                full = os.path.join(dirpath, fn)
                name_hit = ql in fn.lower()
                line_no, snippet = 0, ''
                if not name_hit:
                    if only_name:
                        continue
                    try:
                        if os.path.getsize(full) > 8 * 1024 * 1024:
                            continue
                        with open(full, 'r', encoding='utf-8', errors='replace') as fp:
                            for k, ln in enumerate(fp, 1):
                                if ql in ln.lower():
                                    line_no, snippet = k, ln.strip()[:120]
                                    break
                    except OSError:
                        continue
                    if not line_no:
                        continue
                try:
                    rel_p = os.path.relpath(full, base).replace('\\', '/')
                except ValueError:
                    continue
                hits.append({'name': fn, 'path': rel_p, 'size': os.path.getsize(full),
                             'hit': 'name' if name_hit else 'content',
                             'line': line_no, 'snippet': snippet})
                if len(hits) >= 60:
                    break
            if len(hits) >= 60:
                break
        hits.sort(key=lambda x: (x['hit'] != 'name', x['name'].lower()))
        return self._json({'results': hits, 'mode': 'fulltext'})

    def _api_tree(self, rel):
        root_abs = self._safe(rel)
        if root_abs is None:
            return self._json({'error': 'path escape'}, 403)
        if not os.path.isdir(root_abs):
            return self._json({'error': 'not a dir'}, 400)

        def walk(d):
            items = []
            try:
                entries = sorted(os.listdir(d))
            except PermissionError:
                return items
            for e in entries:
                if e in SKIP_DIRS:
                    continue
                if not entry_ok(e):          # 过滤 nul / con / aux 等保留设备名
                    continue
                full = os.path.join(d, e)
                try:
                    if os.path.islink(full):  # 跳过符号链接 / junction，避免环路与设备路径
                        continue
                except OSError:
                    continue
                try:
                    rel_p = os.path.relpath(full, os.path.realpath(self.root)).replace('\\', '/')
                except ValueError:           # path is on mount 设备路径 —— 兜底跳过
                    continue
                if os.path.isdir(full):
                    # 02178⑥：返回全部文件夹（原先只返回含 md 的），并统计 n_md / has_md
                    children = walk(full)
                    items.append({'name': e, 'type': 'dir', 'path': rel_p,
                                  'children': children,
                                  'n_md': count_md(children),
                                  'has_md': has_md_dir(full),
                                  'mtime': _mtime(full)})
                elif e.lower().endswith(MD_EXT):
                    items.append({'name': e, 'type': 'md', 'path': rel_p,
                                  'size': os.path.getsize(full),
                                  'mtime': _mtime(full)})
            return items

        return self._json({'root': self.root, 'tree': walk(root_abs)})

    def _api_file(self, rel):
        p = self._safe(rel)
        if p is None:
            return self._json({'error': 'path escape'}, 403)
        if not os.path.isfile(p):
            return self._json({'error': 'not a file', 'path': rel}, 404)
        try:
            with open(p, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
        except Exception as e:
            return self._json({'error': str(e)}, 500)
        return self._json({
            'path': rel,
            'dir': os.path.dirname(rel).replace('\\', '/'),
            'name': os.path.basename(p),
            'size': os.path.getsize(p),
            'content': content,
        })

    def _serve_static(self, rel):
        """提供 assets/ 下的前端依赖（katex / marked / highlight / mermaid ...）。
        仅允许 assets 目录内的具体文件，且做路径逃逸校验。
        """
        if not rel or rel.endswith('/'):
            return self._json({'error': 'not found'}, 404)
        base_dir = os.path.join(RES_BASE, 'assets')
        if not os.path.isdir(base_dir):
            base_dir = os.path.join(os.getcwd(), 'assets')
        base_real = os.path.realpath(base_dir)
        target = os.path.realpath(os.path.join(base_real, rel))
        # 逃逸校验：必须在 assets 目录内
        if target != base_real and not target.startswith(base_real + os.sep):
            return self._json({'error': 'path escape'}, 403)
        if not os.path.isfile(target):
            return self._json({'error': 'not found', 'asset': rel}, 404)
        ext = os.path.splitext(target)[1].lower()
        ctype = {'.js': 'application/javascript; charset=utf-8',
                 '.css': 'text/css; charset=utf-8',
                 '.woff': 'font/woff', '.woff2': 'font/woff2',
                 '.ttf': 'font/ttf', '.svg': 'image/svg+xml',
                 '.map': 'application/json; charset=utf-8'}.get(
            ext, 'application/octet-stream')
        try:
            with open(target, 'rb') as f:
                data = f.read()
        except Exception as e:
            return self._json({'error': str(e)}, 500)
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'public, max-age=604800')  # 秒开：强缓存
        self.end_headers()
        self.wfile.write(data)

    OPEN_EXTS = ('.docx', '.doc', '.xlsx', '.xls', '.pptx', '.ppt', '.pdf', '.zip',
                 '.rar', '.7z', '.txt', '.csv', '.mp3', '.mp4')

    def _api_open(self, rel):
        """02209（主公）：非 md 文件用系统默认程序打开（新窗口查看的最优解）——
        对浏览器渲染不了的 docx/xlsx/ppt，硬塞给浏览器只会变下载框。
        阿豆版早有 /open，此处补齐能力对齐（02210）。"""
        p = self._safe(rel)
        if p is None or not os.path.isfile(p):
            return self._json({'error': 'not found', 'path': rel}, 404)
        ext = os.path.splitext(p)[1].lower()
        if ext not in self.OPEN_EXTS:
            return self._json({'error': 'ext not allowed', 'ext': ext}, 400)
        try:
            os.startfile(p)          # noqa: S606 - 本地查看器，白名单后缀
            return self._json({'ok': True, 'opened': rel})
        except Exception as e:
            return self._json({'error': str(e)}, 500)

    def _serve_raw(self, rel):
        p = self._safe(rel)
        if p is None or not os.path.isfile(p):
            return self._json({'error': 'not found'}, 404)
        ext = os.path.splitext(p)[1].lower()
        ctype = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
                 '.gif': 'image/gif', '.svg': 'image/svg+xml', '.webp': 'image/webp',
                 '.bmp': 'image/bmp', '.ico': 'image/x-icon',
                 '.pdf': 'application/pdf',
                 '.txt': 'text/plain; charset=utf-8',
                 '.json': 'application/json; charset=utf-8',
                 '.csv': 'text/csv; charset=utf-8',
                 '.xml': 'application/xml; charset=utf-8',
                 '.htm': 'text/html; charset=utf-8',
                 '.html': 'text/html; charset=utf-8',
                 '.md': 'text/plain; charset=utf-8',
                 '.mp4': 'video/mp4', '.webm': 'video/webm',
                 '.mp3': 'audio/mpeg', '.wav': 'audio/wav',
                 }.get(ext)
        if not ctype:
            # 02209（主公）：非 md 文件点开应是「新窗口直接查看」，不是下载确认框。
            #   octet-stream 会触发浏览器下载 ⇒ 对未知类型改用系统 MIME 推断 + inline。
            try:
                import mimetypes
                ctype = mimetypes.guess_type(p)[0] or 'application/octet-stream'
            except Exception:
                ctype = 'application/octet-stream'
        # 归档/可执行仍然走下载（inline 反而会乱码）
        force_dl = ext in ('.zip', '.rar', '.7z', '.exe', '.msi', '.apk', '.gz', '.tar')
        try:
            with open(p, 'rb') as f:
                data = f.read()
        except Exception as e:
            return self._json({'error': str(e)}, 500)
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Content-Disposition',
                         'attachment' if force_dl else 'inline')
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass


def main():
    ap = argparse.ArgumentParser(description='MD Viewer Pro server (pack-friendly)')
    ap.add_argument('--root', default=None)
    ap.add_argument('--port', type=int, default=0,
                    help='02174 动态端口：默认 0=由系统分配（彻底避开冲突）；'
                         '需固定时用 --port 8782（推荐固定值）')
    ap.add_argument('--open', action='store_true')
    ap.add_argument('--no-open', dest='open', action='store_false')
    # 双击（无参数）时必须自开浏览器，否则用户看到「点开没反应」
    ap.set_defaults(open=True)
    args = ap.parse_args()

    root = resolve_root(args.root)
    log('=' * 56)
    log('MD Viewer Pro 启动')
    log('资源基目录: %s' % RES_BASE)
    log('根目录:     %s' % root)
    log('日志文件:   %s' % LOGPATH)

    page = find_page()
    if not page:
        alert('MD Viewer 启动失败', '缺少前端文件 md-viewer-pro.html\n资源目录：%s' % RES_BASE)

    ViewerHandler.root = root

    port = args.port
    # 02165② 单实例友好：仅当显式指定端口时探测（port=0 为动态分配，不做探测）
    if port and port_in_use(port):
        url0 = 'http://127.0.0.1:%d/' % port
        log('端口 %d 已有实例在运行，改为直接打开该实例：%s' % (port, url0))
        if args.open:
            try:
                import webbrowser
                webbrowser.open(url0)
            except Exception as e:
                log('打开浏览器失败: %s' % e)
        return

    srv = None
    for attempt in range(10):       # 端口占用自动顺延（reuse 关闭后才真正生效）
        try:
            srv = ViewerServer(('127.0.0.1', port), ViewerHandler)
            break
        except OSError:
            log('端口 %d 被占用，尝试 %d' % (port, port + 1))
            port += 1
    if srv is None:
        alert('MD Viewer 启动失败', '端口被占用且无法顺延，服务未启动')
        return

    ViewerHandler.server_holder = srv
    # 02174：port=0 时由系统分配，绑定后取真实端口
    try:
        real_port = srv.server_address[1]
        if real_port:
            port = real_port
    except Exception:
        pass
    url = 'http://127.0.0.1:%d/' % port
    log('访问地址:   %s' % url)

    if args.open:
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception as e:
            log('打开浏览器失败: %s' % e)

    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log('已停止')


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        # 无窗版下任何异常都不应静默
        alert('MD Viewer 启动失败', '%s: %s' % (type(e).__name__, e))
        log('启动异常: %r' % e)
        raise
