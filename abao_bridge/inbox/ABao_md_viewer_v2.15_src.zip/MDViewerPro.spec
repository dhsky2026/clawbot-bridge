# -*- mode: python ; coding: utf-8 -*-
# MDViewerPro（阿宝原型 v2.14）spec —— 专轮-24/25 合并版
# 🔴 02208：补 ffi-8.dll（alert() 走 ctypes MessageBoxW，同样依赖 _ctypes）
# 🔴 02214：datas 补 root.txt（PyInstaller 6.x 落在 _internal/；代码优先读它，避免向上探测误判）
BASE = r'D:\360pan\ClawBot\stock\端口\md_viewer\build-abao-v2.15'

a = Analysis(
    [BASE + r'\viewer_server.py'],
    pathex=[],
    binaries=[
        (r'D:\Games\miniconda3\Library\bin\ffi-8.dll', '.'),
        (r'D:\Games\miniconda3\Library\bin\ffi-7.dll', '.'),
        (r'D:\Games\miniconda3\Library\bin\ffi.dll', '.'),
    ],
    datas=[(BASE + r'\md-viewer-pro.html', '.'),
           (BASE + r'\assets', 'assets'),
           (BASE + r'\root.txt', '.')],
    hiddenimports=['ctypes', 'ctypes.wintypes', '_ctypes'],
    hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False, optimize=0,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True,
    name='MDViewerPro', debug=False, bootloader_ignore_signals=False,
    strip=False, upx=True, console=False, disable_windowed_traceback=False,
    argv_emulation=False, target_arch=None, codesign_identity=None,
    entitlements_file=None, icon=[BASE + r'\abao.ico'],
)
coll = COLLECT(
    exe, a.binaries, a.datas, strip=False, upx=True, upx_exclude=[],
    name='MDViewerPro',
)
